#ifndef _fx_cli_h_
#define _fx_cli_h_

#include <stdint.h>

// ignore this; this is the remains of an early
// draft of the cli.

#define GSYNTH_CMD_SHIFT_FREQ             2
#define GSYNTH_CMD_SHIFT_SPECTRUM         3
#define GSYNTH_CMD_SET_INSTRUMENT_BY_FREQ 4

struct command {
	uint32_t instrument;
	uint32_t id;
	uint32_t flags;
};

#endif // !_fx_cli_h_
