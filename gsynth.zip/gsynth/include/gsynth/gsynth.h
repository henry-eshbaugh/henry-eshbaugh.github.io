#ifndef _gsynth_h_
#define _gsynth_h_

#include <stdbool.h>
#include <stdlib.h>
#include <OpenAL/al.h>
#include <OpenAL/alc.h>
#include <math.h>
#include <errno.h>
#include <gsynth/config.h>
#include <pthread.h>

extern void *midify_core(void *);
extern void *fourier_core(void *);
extern void *fx_cli_core(void *);
extern void *fx_app_core(void *);
extern void *streamin_core(void *);
extern void *harmonic_scrub_core(void *);

extern pthread_mutex_t init_mutex;

// constants.

#define GSYNTH_INPUT_SAMPLE_FREQ 44100
// we use a radix-2 FFT; BUFSZ MUST BE A POWER OF 2.
#define GSYNTH_INPUT_SAMPLE_BUFSZ 8192  
#define GSYNTH_INPUT_SAMPLING_PERIOD (((double)GSYNTH_INPUT_SAMPLE_BUFSZ) / ((double)GSYNTH_INPUT_SAMPLE_FREQ))

// we aren't zero-padding any more; ignore this.
#define GSYNTH_ZPAD_LENGTH (nextpow2(nextpow2(GSYNTH_INPUT_SAMPLE_BUFSZ)) - GSYNTH_INPUT_SAMPLE_BUFSZ)

#ifdef CONFIG_DEBUG_MEMORY
#define gsynth_malloc(size) ({ void *ptr = malloc(size); printf("Gsynth: %s(): allocated %lu bytes at %p...\n", __func__, size, ptr); ptr; })
#define gsynth_free(ptr) do { printf("Gsynth: %s(): freeing %s (%p)\n", __func__, #ptr, ptr); free(ptr); } while (0)
#endif

#ifndef CONFIG_DEBUG_MEMORY
#define gsynth_malloc(size) malloc(size)
#define gsynth_free(ptr) free(ptr)
#endif

#ifdef CONFIG_LOG_SAMPLES
extern unsigned int num_samples_to_log;
#endif

static unsigned int nextpow2(unsigned int n)
{
	return (int) pow(2, (double) ceil(log((double)n / log(2.0))));
}

// We aren't using OpenAL any more.
#if 0
extern ALCdevice *device;
extern ALCcontext *context;
extern ALuint source;
#endif

//#define CHECK_AL_ERROR(x, str) if ((x = alGetError()) != AL_NO_ERROR) { DisplayALError(str, x); exit(-1); }

#endif // !_gsynth_h_
