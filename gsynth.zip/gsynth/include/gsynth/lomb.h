#ifndef GSYNTH_LOMB_H
#define GSYNTH_LOMB_H

#define GSYNTH_DEFAULT_OFAC 4
#define GSYNTH_DEFAULT_HIFAC 1.0

extern void lomb(double *, double **, double **, unsigned long *);

#endif // !GSYNTH_LOMB_H
