#ifndef _gsynth_flipbuffer_h_
#define _gsynth_flipbuffer_h_

#include <pthread.h>

typedef struct flip_buffer_data {
	// this structure is 64-byte aligned so that cache lines
	// don't get thrashed; this is a hot data structure, and
	// that wouldn't be performant.
        void *data;
        struct flip_buffer_data *next, *prev;
	unsigned char _pad[40]; 
} flip_buffer_data_t;
 
 typedef struct flip_buffer {
        // careful in this struct; the alignments are just right here.
	// this also isn't 64-byte aligned for performance reasons,
	// because this isn't likely to get swapped out of cache because
	// it's super-hot and it's better to leave the space for other data.
	// plus, it's hard to align around a pthread_mutex_t.
	flip_buffer_data_t *first, *last;
	pthread_mutex_t mutex;
	int len;
} flip_buffer_t;

extern flip_buffer_t *fft_flip_buffer, *fx_flip_buffer, *midify_flip_buffer, *harmonic_scrub_flip_buffer;

extern void start_flip_buffers(void);
extern void fft_flip_buffer_push(void *);
extern void *fft_flip_buffer_pull(void);
extern void fx_flip_buffer_push(void *);
extern void *fx_flip_buffer_pull(void);
extern void midify_flip_buffer_push(void *);
extern void *midify_flip_buffer_pull(void);
extern void harmonic_scrub_flip_buffer_push(void *);
extern void *harmonic_scrub_flip_buffer_pull(void);

#endif // !_gsynth_flipbuffer_h_
