#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <stdio.h>
#include <time.h>
#include <portaudio.h>

void *streamin_core(void *unused)
{
	printf("Starting streamin...\n");
	PaDeviceIndex device = Pa_GetDefaultInputDevice();
	const PaDeviceInfo *info = Pa_GetDeviceInfo(device);
	printf("Opened default device %s with sampling rate %lf\n", info->name, info->defaultSampleRate);
	PaStream *stream;

	const PaStreamParameters params = {
		.device = device,
		.channelCount = 1,
		.sampleFormat = paFloat32,
		.suggestedLatency = info->defaultLowInputLatency,
		.hostApiSpecificStreamInfo = NULL
	};

	printf("Opening stream... ");
	Pa_OpenStream(&stream, &params, NULL, (double) GSYNTH_INPUT_SAMPLE_FREQ, GSYNTH_INPUT_SAMPLE_BUFSZ, paNoFlag, NULL, NULL);
	printf("opened stream %p; starting... ", stream);
	Pa_StartStream(stream);
	printf("Stream %p started.\n", stream);

	while (1) {
		// capture a sample and enqueue it.
		float *next_samples = gsynth_malloc(sizeof(float) * GSYNTH_INPUT_SAMPLE_BUFSZ);
		Pa_ReadStream(stream, next_samples, GSYNTH_INPUT_SAMPLE_BUFSZ);
		fft_flip_buffer_push(next_samples);
	}	
	return NULL;
}
