#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <stdio.h>
#include <math.h>
#include <samplerate.h>

double *downsize(double *array, int factor)
{
	// downsamples the frequency spectrum.
	int len = GSYNTH_INPUT_SAMPLE_BUFSZ / 2 / factor;
	int i;
	double *ret = gsynth_malloc(sizeof *ret * len);
#ifdef CONFIG_USE_OPENMP
#pragma omp parallel for
#endif
	for (i = 0; i < len; i++)
		ret[i] = array[factor * i];
	return ret;
}

void *harmonic_scrub_core(void *unused)
{
#ifdef CONFIG_LOG_SAMPLES
	FILE *harmonic_dat = fopen("harmonic_scrub.dat", "w");
	unsigned samples_logged = 0u;
#endif
	while (1) {
		double *data = harmonic_scrub_flip_buffer_pull(),
		        abs_spectrum[GSYNTH_INPUT_SAMPLE_BUFSZ/2];
		int i;
#ifdef CONFIG_USE_OPENMP
#pragma omp parallel for
#endif
		// take the absolute value of the spectrum.
		for (i = 0; i < GSYNTH_INPUT_SAMPLE_BUFSZ / 2; i++)
			abs_spectrum[i] = sqrt(data[i] * data[i] + data[GSYNTH_INPUT_SAMPLE_BUFSZ-i] * data[GSYNTH_INPUT_SAMPLE_BUFSZ-i]);
		// generate scaled versions of the spectrums.
		double *scaled2 = downsize(abs_spectrum, 2),
		       *scaled3 = downsize(abs_spectrum, 3),
		       *newdata = gsynth_malloc(sizeof *newdata * GSYNTH_INPUT_SAMPLE_BUFSZ / 2);
#ifdef CONFIG_USE_OPENMP
#pragma omp parallel for
#endif
		// multiply the scaled spectrums together.
		for (i = 0; i < GSYNTH_INPUT_SAMPLE_BUFSZ / 2; i++) {
			newdata[i] = abs_spectrum[i];
			if (i < GSYNTH_INPUT_SAMPLE_BUFSZ / 4 - 1) newdata[i] *= scaled2[i];
			if (i < GSYNTH_INPUT_SAMPLE_BUFSZ / 6 - 1) newdata[i] *= scaled3[i];
		}
		// log samples if we have to.
#ifdef CONFIG_LOG_SAMPLES
		if (samples_logged < num_samples_to_log) {
			for (i = 0; i < GSYNTH_INPUT_SAMPLE_BUFSZ / 2; i++)
				fprintf(harmonic_dat, "%lf, ", newdata[i]);
			samples_logged++;
		}
#endif
		fx_flip_buffer_push(newdata);
		gsynth_free(data);
		gsynth_free(scaled2);
		gsynth_free(scaled3);
	}
}
