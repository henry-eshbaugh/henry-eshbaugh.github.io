#include <gsynth/fx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define strequ(x,y) (!strcmp(x,y))
/*
struct command wait_on_next_command();

char is_separator(char c)
{
	switch (c) {
		case ' ': case '|': case ';':
		case '(': case ')': case '[':
		case ']': case '{': case '}':
			return 1;
		default:
			return 0;
	}
}

struct command generate_command_from_raw_string(char *buf)
{
	char cmd[1025];
	int i = 0;
	// get the command string.
	i = 0;
	for (; i < 1024 && !is_separator(buf[i]); i++) cmd[i] = buf[i];
	for (; i < 1024; i++) cmd[i] = 0;
	cmd[1024] = 0;
	
	if (strequ(cmd, "timbre-scrub"))
		return timbre_scrub_expr(buf + strlen(cmd));
	if (strequ(cmd, "shift-freq"))
		return freq_shift_expr(buf + strlen(cmd));
	if (strequ(cmd, "shift-spectrum"))
		return shift_spectrum_expr(buf + strlen(cmd));
	if (strequ(cmd, "set-instrument-by-freq"))
		return instr_by_freq_expr(buf + strlen(cmd));
	printf("malformed command <%s>\n", cmd);
	// corecursion is fucking _trippy_
	// this is safe, even without tail call optimization;
	//   if we get to the end of the stack 1kb at a time,
	//   there's something more wrong than this program.
	return wait_on_next_command();
}

struct command wait_on_next_command(void)
{
	// grab the next line.
	char buf[1024];
	scanf("%1024s", buf);
	return generate_command_from_raw_string(buf);
}

void apply_command(struct command command)
{
	switch (command.id) {
		// right now this does nothing.
		case GSYNTH_CMD_TIMBRE_SCRUB:
		case GSYNTH_CMD_SHIFT_FREQ:
		case GSYNTH_CMD_SHIFT_SPECTRUM:
		case GSYNTH_CMD_SET_INSTRUMENT_BY_FREQ:
		default:
			break;		
	}
	return;
}
*/
void *fx_cli_core(void *unused)
{
/*
	// TODO: fx cli interface.
	while (1) {
		struct command next = wait_on_next_command();
		apply_command(next);
	}
*/
	return NULL;
} // TODO: fix this shit.
