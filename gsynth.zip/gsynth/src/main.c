#include <portaudio.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <gsynth/config.h>

pthread_t threadpool[5]; // pthread representations of the worker threads.

#ifdef CONFIG_LOG_SAMPLES
// Gsynth can optionally log samples that are captured. Logging
// happens in fourier_analysis.c.
unsigned int num_samples_to_log = 0;
#endif

void sigsegv_handler(int sig, siginfo_t *si, void *unused)
{
	// I had been dealing with segfaults; tracking accesses
	// turned out to be the best way of dealing with them,
	// because gdb is broken horribly on OS X 10.9.
	printf("Segmentation fault accessing %p\n", si->si_addr);
	exit(EXIT_FAILURE);
}

int main(int argc, char *argv[])
{
	// start portaudio
	Pa_Initialize();

	start_flip_buffers();

#ifdef CONFIG_LOG_SAMPLES
	printf("Sample logging is enabled. Number of samples to capture? ");
	scanf("%u", &num_samples_to_log);
#endif	
	// register a sigsegv handler in case we segfault; it's nice to see
	// where the access went wrong.
	struct sigaction sa;
	sa.sa_flags = SA_SIGINFO;
	sigemptyset(&sa.sa_mask);
	sa.sa_sigaction = sigsegv_handler;
	sigaction(SIGSEGV, &sa, NULL);

	// make the worker threads.
	pthread_create(&threadpool[0], NULL, midify_core, NULL);
        pthread_create(&threadpool[1], NULL, fx_cli_core, NULL);
        pthread_create(&threadpool[2], NULL, fx_app_core, NULL);
        pthread_create(&threadpool[3], NULL, fourier_core, NULL);
	pthread_create(&threadpool[4], NULL, harmonic_scrub_core, NULL);
        // become streamin.
        streamin_core(NULL);
}
