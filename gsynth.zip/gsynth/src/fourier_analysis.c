#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <gsynth/lomb.h>
#include <stdint.h>
#include <complex.h>
#include <math.h>
#include <gsl/gsl_fft_real.h>
#include <stdio.h>
#include <stdbool.h>

double hamming(int bin, float sample)
{
	// this used to be a hamming window, but it's a blackman-nutall
	// window now. I was too lazy to refactor.

	double n = (double) bin;
	double N = (double)(GSYNTH_INPUT_SAMPLE_BUFSZ-1);
	double window = 0.3635819
		      - 0.4891775*cos(2.0*M_PI*n / N)
		      + 0.1365995*cos(4.0*M_PI*n / N)
		      - .0106411 *cos(6.0*M_PI*n / N);
	return window * ((double)sample);
	//return (double) ((0.53836 - (0.46164 * cos(2*M_PI*((double)bin) / ((double) (GSYNTH_INPUT_SAMPLE_BUFSZ-1))))) * sample);
}

void *fourier_core(void *unused)
{
#ifdef CONFIG_LOG_SAMPLES
	unsigned int samples_logged = 0u;
#endif
	FILE *out_prehamming, *out_posthamming, *out_fft, *out_lomb_freqs, *out_lomb_powers;
#ifdef CONFIG_LOG_SAMPLES
	out_prehamming = fopen("prehamming.dat", "w");
	out_posthamming = fopen("posthamming.dat", "w");
	out_fft = fopen("fft.dat", "w");
	out_lomb_freqs = fopen("lombfreqs.dat", "w");
	out_lomb_powers = fopen("lombpowers.dat", "w");
	if (!out_prehamming || !out_posthamming || !out_fft || !out_lomb_freqs || out_lomb_powers) {
		printf("fourier_core(): Fatal: bad output stream for data dump: %s.\n",
			out_lomb_powers ? out_lomb_freqs ? out_prehamming ? out_posthamming ?
                        "out_fft" : "out_posthamming" : "out_prehamming" : "out_lomb_freqs" : "out_lomb_powers");
	}
#endif
	printf("Started fourier core...\n");
	// this is the sample we transform; it comes off the flip buffer.
	float *sample;
	// allocated dynamically, and pushed through to the next buffer.
	double *in;
	
	while (1) {
		sample = fft_flip_buffer_pull();
		in = gsynth_malloc(sizeof(double) * GSYNTH_INPUT_SAMPLE_BUFSZ);

		// prepare the sample for processing.
		// this can optionally use OpenMP for speed; the downside is
		// this segment of code looks _ugly_ because of preprocessor
		// directives.
#ifdef CONFIG_USE_OPENMP
#pragma omp parallel for
#endif
		int i = 0;
		for (; i < GSYNTH_INPUT_SAMPLE_BUFSZ; i++) {	
#ifdef CONFIG_LOG_SAMPLES
			if (samples_logged < num_samples_to_log) 
				fprintf(out_prehamming, "%f, ", sample[i]);
#endif

			// run the filtering function.
			in[i] = hamming(i, sample[i]);

#ifdef CONFIG_LOG_SAMPLES
			if (samples_logged < num_samples_to_log)
				fprintf(out_posthamming, "%lf, ", in[i]);
#endif

		}

//		double *lomb_freqs = malloc(sizeof *lomb_freqs * GSYNTH_INPUT_SAMPLE_BUFSZ);
//		double *lomb_powers = malloc(sizeof *lomb_powers * GSYNTH_INPUT_SAMPLE_BUFSZ);
		unsigned long n;
//		lomb(in, &lomb_freqs, &lomb_powers, &n);
		
		gsl_fft_real_radix2_transform(in, /* stride = */ 1, GSYNTH_INPUT_SAMPLE_BUFSZ);
#ifdef CONFIG_LOG_SAMPLES
// this is for debugging and is cold; don't bother tagging it for OMP.
		if (samples_logged++ < num_samples_to_log) {
			for (i = 0; i < GSYNTH_INPUT_SAMPLE_BUFSZ / 2; i++) // GSYNTH_INPUT_SAMPLE_BUFSZ is guaranteed to be a power of 2; this won't give weird results.
				fprintf(out_fft, "%f+%fj, ", in[i], in[GSYNTH_INPUT_SAMPLE_BUFSZ-i]);
			for (i = 0; i < n; i++) {
				if (i == n-1) {
					fprintf(out_lomb_freqs, "%lf, ", lomb_freqs[i]);
					fprintf(out_lomb_powers, "%lf, ", lomb_powers[i]);
				} else {
					fprintf(out_lomb_freqs, "%lf", lomb_freqs[i]);
					fprintf(out_lomb_powers, "%lf", lomb_powers[i]);
				}
			}
		}
#endif
		harmonic_scrub_flip_buffer_push(in);
		
		// ditch the sample; we don't want to leak memory. 
		gsynth_free(sample);
	}
	return NULL;
}
