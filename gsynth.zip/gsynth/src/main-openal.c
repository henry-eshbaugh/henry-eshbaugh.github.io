#include <stdio.h>
#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
//#include <OpenAL/al.h>
//#include <OpenAL/alc.h>
#include <portaudio.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>

pthread_t threadpool[4];

//ALfloat listener_pos[] = { 0.0f, 0.0f, 0.0f }; // position vector
//ALfloat listener_vel[] = { 0.0f, 0.0f, 0.0f }; // velocity vector
//ALfloat listener_ori[] = { 0.0f, 0.0f, 0.0f }; // orientation vector

input_dev_t *input_devs;
ALCdevice *device;
ALCcontext *context;
ALuint source, buffers[GSYNTH_N_BUFS];

static void sigsegv_handler(int sig, siginfo_t *si, void *uc_void)
{
	printf("SIGSEGV at address: %p\n", si->si_addr);
	exit(EXIT_FAILURE);
}

ALCdevice *gsynth_set_active_device(const char *devs)
{
	ALCdevice *ret;
	/* so this shit wasn't working, so we do alcOpenDevice("") instead.
	// variables
	const char *_default = devs;
	int i = 0, alloced = 16;
	input_devs = malloc(alloced * sizeof *input_devs);
	input_dev_t *current_dev = input_devs;
	bool first_pass = true;
	
	// list detected devices on stdout while we build this list.
	printf("detected devices:");
	// the last device name will end with two null bytes.
	while (*devs || *(devs+1)) {
		if (first_pass || *(devs-1) == '\0') { // IOW, for each new string.
			first_pass = false;
			
			printf("\t%s\n", devs); // list the device on stdout.
			current_dev->dev_name = malloc(1024);
			strncpy(current_dev->dev_name, devs, 1024);
			current_dev->ident = i++;
			current_dev++;
			devs++;
			// we support an infinite (_in theory_) number of devices;
			// don't choke if we get more than 16, just reallocate the
			// structure.
			if (i == alloced) {
				alloced *= 2;
				input_devs = realloc(input_devs, 
						alloced * sizeof *input_devs);
				printf("Realloc: %lu bytes\n", alloced * sizeof *input_devs);
				current_dev = input_devs + i;
			}
		}
	}
	printf("defaulting to device: %s\n", _default); */
	ret = alcCaptureOpenDevice(alcGetString(NULL, ALC_CAPTURE_DEFAULT_DEVICE_SPECIFIER),
				GSYNTH_INPUT_SAMPLE_FREQ, GSYNTH_INPUT_SAMPLE_FMT, GSYNTH_INPUT_SAMPLE_BUFSZ);
	return ret;
}

int main(int argc, char *argv[])
{
	const char *devs = alcGetString(NULL, ALC_CAPTURE_DEVICE_SPECIFIER);
	device = gsynth_set_active_device(devs);
	printf("Available capture devices are:\n");
	while (*devs) {
		printf("\t%s\n", devs);	
		devs += strlen(devs) + 1;
	}
	printf("Default capture device is %s\n", alcGetString(NULL, ALC_CAPTURE_DEFAULT_DEVICE_SPECIFIER));
	bool started = false;

	struct sigaction sa_sigsegv;
	sa_sigsegv.sa_flags = SA_SIGINFO;
	sigemptyset(&sa_sigsegv.sa_mask);
	sa_sigsegv.sa_sigaction = sigsegv_handler;
	sigaction(SIGSEGV, &sa_sigsegv, NULL);	
	
	alGenBuffers(GSYNTH_N_BUFS, buffers);

	// set position, velocity, and orientation vectors to zero;
	// we don't want to fuck with the sound of the guitar by making
	// it a stereo channel, plus extra processing is bad for performance.
	alListenerfv(AL_POSITION, listener_pos);
	alListenerfv(AL_VELOCITY, listener_vel);
	alListenerfv(AL_ORIENTATION, listener_ori);

	// we don't care where the guitar is in space;
	// don't bother with stero processing.
	alDistanceModel(AL_NONE);	

	// initialize program-wide data sharing constructs.
	start_flip_buffers();

	// start the pipeline: streamin -> fourier transformer -> fx -> midify
	pthread_create(&threadpool[0], NULL, midify_core, NULL);
	pthread_create(&threadpool[1], NULL, fx_cli_core, NULL);
	pthread_create(&threadpool[2], NULL, fx_app_core, NULL);
	pthread_create(&threadpool[3], NULL, fourier_core, NULL);
	// become streamin.
	streamin_core(NULL);
}
