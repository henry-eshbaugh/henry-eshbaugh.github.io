#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <gsynth/midi.h>
#include <math.h>
#include <complex.h>
#include <jack/jack.h>
#include <jack/midiport.h>
#include <jack/session.h>
#include <stdio.h>
#include <string.h>
#include <libkern/OSAtomic.h> // for spinlocks

static jack_client_t *client;
static jack_port_t *out;
double *freq_spectrum;
jack_nframes_t nframes;
double *new_sample;
OSSpinLock freq_spectrum_lock;
unsigned char updated;

static double margin_of_error_midi_note_high(int midi_freq)
{
	return (freq_by_midi_table[midi_freq+1] - freq_by_midi_table[midi_freq]) / 2.0;
}

static double margin_of_error_midi_note_low(int midi_freq)
{
	return (freq_by_midi_table[midi_freq] - freq_by_midi_table[midi_freq-1]) / 2.0;
}

static double bin_to_freq(int bin)
{
#define dbl(x) ((double)x)
	return dbl(bin) * dbl(GSYNTH_INPUT_SAMPLE_FREQ)
		/ dbl(GSYNTH_INPUT_SAMPLE_BUFSZ);
#undef dbl
}

unsigned char freq_to_midi_note(double freq)
{
	unsigned char note = 0;
	while (note < 255) {
		if (freq < freq_by_midi_table[note] + margin_of_error_midi_note_high(note)
		 && freq > freq_by_midi_table[note] - margin_of_error_midi_note_low(note))
			return note;
		note++;
	}
	return 0;
}

static void midify_error(const char *desc) { printf("Error in JACK: %s\n", desc); }

static void midify_shutdown(void *arg) { exit(1); }

unsigned char last_note_on = 0;

int process(jack_nframes_t nframes, void *arg)
{
	// this is a realtime task; JACK docs say we aren't
	// even supposed to call printf(). That means no mutices.
	OSSpinLockLock(&freq_spectrum_lock);

	if (!updated)
		goto out;

	void *port_buf = jack_port_get_buffer(out, nframes);

	unsigned char *buf, *noteoff;
	int i = 0, max_offset = 0;
	double max = 0.0;


	jack_midi_clear_buffer(port_buf);

	// find the dominant frequency in the signal; because
	// we applied a harmonic scrub, this will be the only note
	// we need to worry about.
	for (; i < GSYNTH_INPUT_SAMPLE_BUFSZ / 2; i++) {
		if (freq_spectrum[i] > max) {
			max = freq_spectrum[i];
			max_offset = i;
		}
	}
	
	if (max < 1.0)
		goto out;

	if (last_note_on) {
		noteoff = jack_midi_event_reserve(port_buf, 0, 3);
		noteoff[0] = 0x80;
		noteoff[1] = last_note_on;
		noteoff[2] = 0;
	}

	buf = jack_midi_event_reserve(port_buf, 0, 3);

	buf[0] = 0x90; // note on.
	buf[1] = last_note_on = freq_to_midi_note(bin_to_freq(max_offset));
	buf[2] = 64;

	printf("MIDI note on event: %d\n", last_note_on);

	out:
	OSSpinLockUnlock(&freq_spectrum_lock);
	return 0;
}

void session_state_notify_handler(jack_session_event_t *event, void *arg)
{
	printf("Got jack event: ");
	switch (event->type) {
		case JackSessionSave:
			printf("JackSessionSave\n");
			break;
		case JackSessionSaveAndQuit:
			printf("JackSessionSaveAndQuit\n");
			break;
		case JackSessionSaveTemplate:
			printf("JackSessionSaveTemplate\n");
			break;
	}
	jack_session_reply(client, event);
}

int sample_rate_change_notify_handler(jack_nframes_t nframes, void *arg)
{
	printf("The system sample rate is now %dHz.\n", nframes);
	return 0;
}

void *midify_core(void *unused)
{
	double *new_spectrum;
	freq_spectrum = NULL;
	updated = 0;
	printf("Starting midifier...\n");

	// initialize the spinlock. There's no helper for it, 
	// so we make sure it's unlocked.	
	OSSpinLockTry(&freq_spectrum_lock);
	OSSpinLockUnlock(&freq_spectrum_lock);

	// turn jack on, also, start the server
	printf("Registering error callback... ");
	jack_set_error_function(midify_error);
	printf("registered.\n");

	printf("Connecting to jack... ");
	client = jack_client_open("gsynth", JackUseExactName, NULL);
	if (!client) {
		printf("Fatal: no jack client. Is the server running?\n");
		exit(2);
	}
	printf("connected.\n");
	
	printf("Getting buffer size... ");
	nframes = jack_get_buffer_size(client);
	printf("Buffer size is %d bytes.\n", nframes);
	
	jack_on_shutdown(client, midify_shutdown, 0);
	printf("Asking to be assigned a port... ");
	out = jack_port_register(client, "gsynth", JACK_DEFAULT_MIDI_TYPE, 
			JackPortIsOutput, 0);
	printf("registered, port is %p.\n", out);

	// if jack is turning on, dues that mean we've stopped jacking off? 
	printf("Registering sample rate change handler... ");
	jack_set_sample_rate_callback(client, sample_rate_change_notify_handler, NULL);
	printf("Registering session state change handler... ");
	jack_set_session_callback(client, session_state_notify_handler, NULL);
	printf("registered.\n");
	
	printf("Registering process callback... ");
	jack_set_process_callback(client, process, NULL);
	printf("registered.\n");
	
	printf("Activating client... ");
	if (jack_activate(client)) {
		printf("Fatal: cannot activate client.\n");	
		exit(2);
	}
	printf("activated.\n");	
	printf("Waiting for samples...\n");


	while (1) { // make sure the frequency spectrum is up-to-date
		new_spectrum = midify_flip_buffer_pull();
		printf("midify_core(): got new spectrum at %p\n", new_spectrum);
		OSSpinLockLock(&freq_spectrum_lock);
		freq_spectrum = new_spectrum;
		updated = 1;
		OSSpinLockUnlock(&freq_spectrum_lock);
	}
	
	return NULL;
}
