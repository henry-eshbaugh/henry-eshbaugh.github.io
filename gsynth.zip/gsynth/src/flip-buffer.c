#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>
#include <pthread.h>
#include <stdio.h>

// these could have been generalized so that the flip buffer was passed as a parameter
// instead of being specified in the function name, but I wrote a python script instead
// to write them for me. These are all hot anyways, so they should exist independently
// in the code section.

flip_buffer_t *fft_flip_buffer, *harmonic_scrub_flip_buffer, *fx_flip_buffer, *midify_flip_buffer;

void start_flip_buffers(void)
{
	printf("Starting flip buffers... ");
	// make space on the heap
	fft_flip_buffer = gsynth_malloc(sizeof *fft_flip_buffer);
	fx_flip_buffer = gsynth_malloc(sizeof *fx_flip_buffer);
	midify_flip_buffer = gsynth_malloc(sizeof *midify_flip_buffer);
	harmonic_scrub_flip_buffer = gsynth_malloc(sizeof *harmonic_scrub_flip_buffer);

	// initialize all the data.
	fft_flip_buffer->len = midify_flip_buffer->len = fx_flip_buffer->len 
		= harmonic_scrub_flip_buffer->len = 0;
	fft_flip_buffer->first = fft_flip_buffer->last =
		midify_flip_buffer->first = midify_flip_buffer->last =
		fx_flip_buffer->first = fx_flip_buffer->last =
		harmonic_scrub_flip_buffer->first = harmonic_scrub_flip_buffer->last =
			NULL;
	// make sure the mutices work
	pthread_mutex_init(&fft_flip_buffer->mutex, NULL);
	pthread_mutex_init(&fx_flip_buffer->mutex, NULL);
	pthread_mutex_init(&midify_flip_buffer->mutex, NULL);
	pthread_mutex_init(&harmonic_scrub_flip_buffer->mutex, NULL);
	
	printf("done.\n");
	return;
}

void fft_flip_buffer_push(void *data)
{
	// prepare the data for insertion into the list.
//	printf("Pushing to fft flip buffer; data=%p...\n", data);
	flip_buffer_data_t *pkt = gsynth_malloc(sizeof *pkt);
	pkt->data = data;

	// serialize
	pthread_mutex_lock(&fft_flip_buffer->mutex);
	
	if (fft_flip_buffer->len == 0) fft_flip_buffer->first = fft_flip_buffer->last = pkt;
	else if (fft_flip_buffer->len == 1) fft_flip_buffer->first->next = fft_flip_buffer->last = pkt;
	else fft_flip_buffer->last = fft_flip_buffer->last->next = pkt;

	fft_flip_buffer->len++;
	
	// deserialize and return.
	pthread_mutex_unlock(&fft_flip_buffer->mutex);
	return;
}

void *fft_flip_buffer_pull(void)
{
	void *data, *old_container;

	not_ready_yet: 
	pthread_mutex_lock(&fft_flip_buffer->mutex);

	switch (fft_flip_buffer->len) {
		case 0: pthread_mutex_unlock(&fft_flip_buffer->mutex); goto not_ready_yet; // no data to yield
		case 1:
			// only one piece of data to yield; this requires some special handling.
			data = fft_flip_buffer->first->data;
			gsynth_free(fft_flip_buffer->first);
			break;
		default:
			// multiple samples are queued up.
			data = fft_flip_buffer->first->data;
			old_container = fft_flip_buffer->first;
			fft_flip_buffer->first = fft_flip_buffer->first->next;
			gsynth_free(old_container);
			break;
	}
	// centralized cleanup of the list.
	//printf("fft flip buffer pull: got data at %p\n", data);
	fft_flip_buffer->len--;
	pthread_mutex_unlock(&fft_flip_buffer->mutex);
	return data;
}

void fx_flip_buffer_push(void *data)
{
	flip_buffer_data_t *pkt = gsynth_malloc(sizeof *pkt);
	pkt->data = data;
	pthread_mutex_lock(&fx_flip_buffer->mutex);
	if (fx_flip_buffer->len == 0) fx_flip_buffer->first = fx_flip_buffer->last = pkt;
	else if (fx_flip_buffer->len == 1) fx_flip_buffer->first->next = fx_flip_buffer->last = pkt;
	else fx_flip_buffer->last = fx_flip_buffer->last->next = pkt; // this works because assignment is right-to-left; learn C, scrub!
	fx_flip_buffer->len++;
	pthread_mutex_unlock(&fx_flip_buffer->mutex);
	return;
}

void *fx_flip_buffer_pull(void)
{
	void *data, *old_container;
	not_ready_yet: pthread_mutex_lock(&fx_flip_buffer->mutex);
	switch (fx_flip_buffer->len) {
	case 0: pthread_mutex_unlock(&fx_flip_buffer->mutex); goto not_ready_yet;
		case 1:
			data = fx_flip_buffer->first->data;
			gsynth_free(fx_flip_buffer->first);
			fx_flip_buffer->len--;
			pthread_mutex_unlock(&fx_flip_buffer->mutex);
			break;
		default:
			data = fx_flip_buffer->first->data;
			old_container = fx_flip_buffer->first;
			fx_flip_buffer->first = fx_flip_buffer->first->next;
			gsynth_free(old_container);
			fx_flip_buffer->len--;
			pthread_mutex_unlock(&fx_flip_buffer->mutex);
			break;
	}
	return data;
}

void midify_flip_buffer_push(void *data)
{
	flip_buffer_data_t *pkt = gsynth_malloc(sizeof *pkt);
	pkt->data = data;
	pthread_mutex_lock(&midify_flip_buffer->mutex);
	if (midify_flip_buffer->len == 0) midify_flip_buffer->first = midify_flip_buffer->last = pkt;
	else if (midify_flip_buffer->len == 1) midify_flip_buffer->first->next = midify_flip_buffer->last = pkt;
	else midify_flip_buffer->last = midify_flip_buffer->last->next = pkt; // this works because assignment is right-to-left; learn C, scrub!
	midify_flip_buffer->len++;
	pthread_mutex_unlock(&midify_flip_buffer->mutex);
	return;
}

void *midify_flip_buffer_pull(void)
{
	void *data, *old_container;
	not_ready_yet: pthread_mutex_lock(&midify_flip_buffer->mutex);
	switch (midify_flip_buffer->len) {
		case 0: pthread_mutex_unlock(&midify_flip_buffer->mutex); goto not_ready_yet;
		case 1:
			data = midify_flip_buffer->first->data;
			gsynth_free(midify_flip_buffer->first);
			midify_flip_buffer->len--;
			pthread_mutex_unlock(&midify_flip_buffer->mutex);
			break;
		default:
			data = midify_flip_buffer->first->data;
			old_container = midify_flip_buffer->first;
			midify_flip_buffer->first = midify_flip_buffer->first->next;
			gsynth_free(old_container);
			midify_flip_buffer->len--;
			pthread_mutex_unlock(&midify_flip_buffer->mutex);
			break;
	}
	return data;
}

void harmonic_scrub_flip_buffer_push(void *data)
{
	// prepare the data for insertion into the list.
//	printf("Pushing to harmonic_scrub flip buffer; data=%p...\n", data);
	flip_buffer_data_t *pkt = gsynth_malloc(sizeof *pkt);
	pkt->data = data;

	// serialize
	pthread_mutex_lock(&harmonic_scrub_flip_buffer->mutex);
	
	if (harmonic_scrub_flip_buffer->len == 0) harmonic_scrub_flip_buffer->first = harmonic_scrub_flip_buffer->last = pkt;
	else if (harmonic_scrub_flip_buffer->len == 1) harmonic_scrub_flip_buffer->first->next = harmonic_scrub_flip_buffer->last = pkt;
	else harmonic_scrub_flip_buffer->last = harmonic_scrub_flip_buffer->last->next = pkt;

	harmonic_scrub_flip_buffer->len++;
	
	// deserialize and return.
	pthread_mutex_unlock(&harmonic_scrub_flip_buffer->mutex);
	return;
}

void *harmonic_scrub_flip_buffer_pull(void)
{
	void *data, *old_container;

	not_ready_yet: 
	pthread_mutex_lock(&harmonic_scrub_flip_buffer->mutex);

	switch (harmonic_scrub_flip_buffer->len) {
		case 0: pthread_mutex_unlock(&harmonic_scrub_flip_buffer->mutex); goto not_ready_yet; // no data to yield
		case 1:
			// only one piece of data to yield; this requires some special handling.
			data = harmonic_scrub_flip_buffer->first->data;
			gsynth_free(harmonic_scrub_flip_buffer->first);
			break;
		default:
			// multiple samples are queued up.
			data = harmonic_scrub_flip_buffer->first->data;
			old_container = harmonic_scrub_flip_buffer->first;
			harmonic_scrub_flip_buffer->first = harmonic_scrub_flip_buffer->first->next;
			gsynth_free(old_container);
			break;
	}
	// centralized cleanup of the list.
	//printf("harmonic_scrub flip buffer pull: got data at %p\n", data);
	harmonic_scrub_flip_buffer->len--;
	pthread_mutex_unlock(&harmonic_scrub_flip_buffer->mutex);
	return data;
}
