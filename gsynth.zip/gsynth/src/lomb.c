#include <math.h>
#include <nrutil/nrutil.h>
#include <gsl/gsl_fft_real.h>
#include <gsynth/gsynth.h>
#include <gsynth/lomb.h>

#define MOD(a,b) while (a >= b) a -= b
#define SWAP(a,b) tempr=(a);(a)=(b); (b)=tempr
#define MACC 4

void avevar(double data[], unsigned long n, double *ave, double *var)
{
	unsigned long j;
	double s,ep;
	for (*ave=0.0,j=1;j<=n;j++) *ave += data[j];
	*ave /= n;
	*var=ep=0.0;
	for (j=1;j<=n;j++) {
		s=data[j]-(*ave);
		ep += s;
		*var += s*s;
	}
	*var=(*var-ep*ep/n)/(n-1);
}

void four1(double *data, unsigned long nn, int isign)
{
	unsigned long n,mmax,m,j,istep,i;
	double wtemp,wr,wpr,wpi,wi,theta;
	double tempr,tempi;
	n=nn << 1;
	j=1;
	for (i=1;i<n;i+=2) {
		if (j > i) {
			SWAP(data[j],data[i]);
			SWAP(data[j+1],data[i+1]);
		}
		m=nn;
		while (m >= 2 && j > m) {
			j -= m;
			m >>= 1;
		}
		j += m;
	}
	mmax=2;
	while (n > mmax) {
		istep=mmax << 1;
		theta=isign*(6.28318530717959/mmax);
		wtemp=sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sin(theta);
		wr=1.0;
		wi=0.0;
		for (m=1;m<mmax;m+=2) {
			for (i=m;i<=n;i+=istep) {
				j=i+mmax;
				tempr=wr*data[j]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j]=data[i]-tempr;
				data[j+1]=data[i+1]-tempi;
				data[i] += tempr;
				data[i+1] += tempi;
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

void realft(double *data, unsigned long n, int isign)
{
	unsigned long i,i1,i2,i3,i4,np3;
	double c1=0.5,c2,h1r,h1i,h2r,h2i;
	double wr,wi,wpr,wpi,wtemp,theta;
	theta=3.141592653589793/(double) (n>>1);
	if (isign == 1) {
		c2 = -0.5;
		four1(data,n>>1,1);
	} else {
		c2=0.5;
		theta = -theta;
	}
	wtemp=sin(0.5*theta);
	wpr = -2.0*wtemp*wtemp;
	wpi=sin(theta);
	wr=1.0+wpr;
	wi=wpi;
	np3=n+3;
	for (i=2;i<=(n>>2);i++) {
		i4=1+(i3=np3-(i2=1+(i1=i+i-1)));
		h1r=c1*(data[i1]+data[i3]); 
		h1i=c1*(data[i2]-data[i4]);
		h2r = -c2*(data[i2]+data[i4]);
		h2i=c2*(data[i1]-data[i3]);
		data[i1]=h1r+wr*h2r-wi*h2i;
		data[i2]=h1i+wr*h2i+wi*h2r;
		data[i3]=h1r-wr*h2r+wi*h2i;
		data[i4] = -h1i+wr*h2i+wi*h2r;
		wr=(wtemp=wr)*wpr-wi*wpi+wr;
		wi=wi*wpr+wtemp*wpi+wi;
	}

	if (isign == 1) {
		data[1] = (h1r=data[1])+data[2];
		data[2] = h1r-data[2];
	} else {
		data[1]=c1*((h1r=data[1])+data[2]);
		data[2]=c1*(h1r-data[2]);
		four1(data, n>>1, -1);
	}
}

void spread(double y, double *yy, unsigned long n, double x, int m)
{
	int ihi,ilo,ix,j,nden;
	static long nfac[11]={0,1,1,2,6,24,120,720,5040,40320,362880};
	double fac;
	if (m > 10) nrerror("factorial table too small in spread");
	ix=(int)x;
	if (x == (double)ix) yy[ix] += y;
	else {
		ilo=LMIN(LMAX((long)(x-0.5*m+1.0),1),n-m+1);
		ihi=ilo+m-1;
		nden=nfac[m];
		fac=x-ilo;
		for (j=ilo+1;j<=ihi;j++) fac *= (x-j);
		yy[ihi] += y*fac/(nden*(x-ihi));
		for (j=ihi-1;j>=ilo;j--) {
			nden=(nden/(j+1-ilo))*(j-ihi);
			yy[j] += y*fac/(nden*(x-j));
		}
	}
}

void fasper(double *x, double *y, unsigned long n, double ofac, 
	    double hifac, double *wk1, double *wk2, unsigned long nwk,
	    unsigned long *nout, unsigned long *jmax, double *prob)
{
	unsigned long j,k,ndim,nfreq,nfreqt;
	double ave,ck,ckk,cterm,cwt,den,df,effm,expy,fac,fndim,hc2wt;
	double hs2wt,hypo,pmax,sterm,swt,var,xdif,xmax,xmin;
	*nout=0.5*ofac*hifac* n;
	nfreqt = ofac * hifac * n * MACC;
	nfreq=64;
	while (nfreq < nfreqt) nfreq <<= 1;
	ndim=nfreq << 1;
	if (ndim > nwk) nrerror("workspaces too small in fasper");
	avevar(y,n,&ave,&var);
	if (var == 0.0) nrerror("zero variance in fasper");
	xmin=x[1];
	xmax=xmin;
	for (j=2;j<=n;j++) {
		if (x[j] < xmin) xmin=x[j];
		if (x[j] > xmax) xmax=x[j];
	}
	xdif=xmax-xmin;
	for (j=1;j<=ndim;j++) wk1[j]=wk2[j]=0.0;
	fac=ndim/(xdif*ofac);
	fndim=ndim;
	for (j=1;j<=n;j++) {
		ck=(x[j]-xmin)*fac;
		MOD(ck,fndim);
		ckk=2.0*(ck++);
		MOD(ckk,fndim);
		++ckk;
		spread(y[j]-ave,wk1,ndim,ck,MACC);
		spread(1.0,wk2,ndim,ckk,MACC);
	}
	realft(wk1,ndim,1);
	realft(wk2,ndim,1);
	df=1.0/(xdif*ofac);
	pmax = -1.0;
	for (k=3,j=1;j<=(*nout);j++,k+=2) {
		hypo=sqrt(wk2[k]*wk2[k]+wk2[k+1]*wk2[k+1]);
		hc2wt=0.5*wk2[k]/hypo;
		hs2wt=0.5*wk2[k+1]/hypo;
		cwt=sqrt(0.5+hc2wt);
		swt=SIGN(sqrt(0.5-hc2wt),hs2wt);
		den = 0.5 * n + hc2wt * wk2[k] + hs2wt * wk2[k+1];
		cterm = SQR(cwt*wk1[k]+swt*wk1[k+1])/den;
		sterm=SQR(cwt*wk1[k+1]-swt*wk1[k])/(n-den);
		wk1[j]=j*df;
		wk2[j]=(cterm+sterm)/(2.0*var);
		if (wk2[j] > pmax) pmax=wk2[(*jmax=j)];
	}
	effm=2.0*(*nout)/ofac;
	*prob=effm*expy;
	if (*prob > 0.01) *prob=1.0-pow(1.0-expy,effm);
}

// I am so done with lomb analysis it's not even funny.
void lomb(double *array, double **out1, double **out2, unsigned long *nout)
{
	double x[GSYNTH_INPUT_SAMPLE_BUFSZ];
	for (int i = 0; i < GSYNTH_INPUT_SAMPLE_BUFSZ; i++)
		x[i] = (double) i;
	*out1 = gsynth_malloc(sizeof (double) * GSYNTH_INPUT_SAMPLE_BUFSZ);
	*out2 = gsynth_malloc(sizeof (double) * GSYNTH_INPUT_SAMPLE_BUFSZ);
	unsigned long jmax;
	double prob;

	fasper(x, array, GSYNTH_INPUT_SAMPLE_BUFSZ, GSYNTH_DEFAULT_OFAC, GSYNTH_DEFAULT_HIFAC,
               *out1, *out2, 8 * sizeof(double) * GSYNTH_INPUT_SAMPLE_BUFSZ, nout, &jmax, &prob);
		
}
