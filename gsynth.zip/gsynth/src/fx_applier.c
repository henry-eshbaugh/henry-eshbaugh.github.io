#include <gsynth/gsynth.h>
#include <gsynth/flipbuffer.h>

void *fx_app_core(void *unused)
{
	// TODO: fx.
	while (1) midify_flip_buffer_push(fx_flip_buffer_pull());
	return NULL;
}
