# this script uses the scilab stack to make pretty graphs out of logged samples.

from pylab import *
import numpy as np

predat = genfromtxt("prehamming.dat", delimiter=', ')
postdat = genfromtxt("posthamming.dat", delimiter=', ')
fftdat = genfromtxt("fft.dat", delimiter=', ', dtype=str)
harmonic_dat = genfromtxt("harmonic_scrub.dat", delimiter=', ')

# the last part of the fft data might be missing a j, which breaks mapping complex() over the list.
#if fftdat[len(fftdat)-1][len(fftdat[len(fftdat-1)]):] != 'j': fftdat[len(fftdat)-1] += 'j'
fftdat = complex_(fftdat)
fftdat = abs(fftdat)

time_axis = arange(0, len(predat), 1)
freq_axis = arange(0, len(fftdat), 1)
freq_axis *= 44100 / 8192.0

harmonic_axis = arange(0, len(harmonic_dat), 1)
harmonic_axis *= 44100 / 8192.0

figure(1)
plot(time_axis, predat)
xlabel("Time (1/44100 s)")
ylabel("PCM reading from PortAudio, pre-hamming window (unitless)")
title("Time-series PCM data, before applying a hamming window")

figure(2)
plot(time_axis, postdat)
xlabel("Time (1/44100 s)")
ylabel("PCM reading from PortAudio, post-hamming window (unitless)")
title("Time-series PCM data, after applying a hamming window")

figure(3)
plot(freq_axis, fftdat)
xlabel("Frequency (Hz)")
ylabel("|Y(t)|")
title("Frequency spectrum for post-hamming window PCM data, before scrubbing harmonics")

figure(4)
plot(harmonic_axis, harmonic_dat)
xlabel("Frequency (Hz)")
ylabel("|Y(t)|")
title("Frequency spectrum for post-hamming window PCM data, after scrubbing harmonics")

show()
